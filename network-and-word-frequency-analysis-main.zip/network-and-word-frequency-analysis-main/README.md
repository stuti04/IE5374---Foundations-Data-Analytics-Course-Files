## Network and Word Frequency Analysis

### Project Description

This project was implemented as a part of the project series of my foundations of data analytics course at Northeastern University. As part of this project, I performed  keyword network analysis by extracting keyword data, computing the weighted adjacency matrix, and then converting it to a weighted network using Python. I also worked on Elon Musk's twitter data to generate word frequencies for each year in the dataset. Finally, the results of both the tasks were visualized in Python and R. Any suggestions regarding modifications and/or additions to the code are **highly appreciated**.

### Contact 

LinkedIn - https://www.linkedin.com/in/stuti-dhebar/
